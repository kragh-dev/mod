create database modDB

use modDB

create table skill(
	[id] [bigint] IDENTITY(1,1) primary key NOT NULL,
	[name] [varchar](30) NOT NULL,
	[toc] [varchar](40) NOT NULL,
	[prerequistes] [varchar](100) NULL
)

create table [user](
	[id] [bigint] IDENTITY(1,1) primary key NOT NULL,
	[user_name] [varchar](100) NOT NULL,
	[password][varchar] (100) NOT NULL,
	[first_name] [varchar](50) NOT NULL,
    [last_name] [varchar](50) NOT NULL,
	[contact_number][bigint] NOT NULL,
	[reg_code] [varchar] (50) NULL,
	[role][varchar] (10) NOT NULL,
	[linkedin_url][varchar](200) NULL,
	[years_of_experience] [int] NULL,
	[active][bit] NOT NULL,
	[reject][bit] NOT NULL,
	[comments][varchar](100)NULL
)