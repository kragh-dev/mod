import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {

  loggedInUser
  role: string
  baseUrl = 'http://10.230.170.96:5000/api/'
  constructor(private http: HttpClient) { }

  authenticateUser(credentials:any)
  {
    let body = JSON.stringify(credentials.value)
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.post(this.baseUrl+"/user/userLogin",body,options)
  }

  authenticateAdmin(credentials:any)
  {
    let body = JSON.stringify(credentials.value)
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.post(this.baseUrl+"/admin/adminLogin",body,options)
  }

  authenticateMentor(credentials:any)
  {
    let body = JSON.stringify(credentials.value)
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.post(this.baseUrl+"/mentor/mentorLogin",body,options)
  }
}
