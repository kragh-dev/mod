import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-user-signup',
  templateUrl: './user-signup.component.html',
  styleUrls: ['./user-signup.component.css']
})
export class UserSignupComponent implements OnInit {

  isMentor: boolean
  isUser: boolean
  mentorCreationForm: FormGroup
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.isMentor = false
    this.isUser = false
    this.mentorCreationForm = this.formBuilder.group({
      adminId:['',[Validators.maxLength(6),Validators.pattern('[0-9]*$')]],
      firstName:['',[Validators.required, Validators.maxLength(20)]],
      lastName:['',Validators.required],
      age:['',Validators.required],
      gender:['',Validators.required],
      contactNumber:['',[Validators.required, Validators.maxLength(10), Validators.pattern('[0-9]*$')]],
      branch:['',[Validators.required, Validators.maxLength(20)]],
      password:['',[Validators.required,Validators.minLength(8)]],
      emailId:['',[Validators.required, Validators.email]],
      status:[false],
      reject:[false],
      role:['']
    })
  }

  mentorClick()
  {
    this.isMentor = true
    this.isUser = false
  }
  userClick()
  {
    this.isMentor = false
    this.isUser = true
  }

}
