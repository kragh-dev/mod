import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthServiceService } from 'src/app/service/auth-service.service';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

  loginForm: FormGroup
  isAdmin: boolean
  isMentor: boolean
  isUser: boolean

  constructor(private formBuilder: FormBuilder, private authService: AuthServiceService) { }

  ngOnInit() {
    this.isAdmin = false
    this.isMentor = false
    this.isUser = false
    this.loginForm = this.formBuilder.group({
      username: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]]
    });
  }

  get formControls() { return this.loginForm.controls; }

  adminClick()
  {
    this.isAdmin = true
    this.isMentor = false
    this.isUser = false
  }
  mentorClick()
  {
    this.isAdmin = false
    this.isMentor = true
    this.isUser = false
  }
  userClick()
  {
    this.isAdmin = false
    this.isMentor = false
    this.isUser = true
  }
  onLogin()
  {
    if(this.isUser == true)
    {
      this.authService.authenticateUser(this.loginForm).subscribe(
        data => {
          if(data['message'] == "Valid")
          {
            console.log(data)
          }
        }
      )
    }
    if(this.isAdmin == true)
    {
      this.authService.authenticateAdmin(this.loginForm).subscribe(
        data => {
          if(data['message'] == "Valid")
          {
            console.log(data)
          }
        }
      )
    }
    if(this.isMentor == true)
    {
      this.authService.authenticateMentor(this.loginForm).subscribe(
        data => {
          if(data['message'] == "Valid")
          {
            console.log(data)
          }
        }
      )
    }
  }
}
