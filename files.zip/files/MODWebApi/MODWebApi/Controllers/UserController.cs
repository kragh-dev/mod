﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MODWebApi.Models;

namespace MODWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        modDBContext modcontext = new modDBContext();
        [Route("proposeTraining/{id}/{userId}/{userName}")]
        [HttpPost("{id}/{userId}/{userName}")]
        public IActionResult ProposeTraining(long id,long userId, string userName)
        {
            Training training = new Training();
            var course = modcontext.Course.Where(p => p.Id == id).FirstOrDefault();
            training.Completed = false;
            training.Progress = 0;
            training.CourseId = id;
            training.SkillId = course.SkillId;
            training.SkillName = course.SkillName;
            training.MentorId = course.MentorId;
            training.MentorName = course.MentorName;
            training.UserId = userId;
            training.UserName = userName;
            training.Approved = false;
            training.StartDate = DateTime.Now;
            training.PartOne = false;
            training.PartTwo = false;
            training.PartThree = false;
            training.PartFour = false;
            training.Rating = course.Rating;
            training.PaymentStatus = false;
         
          
            training.Fees = course.Fees;
            training.CommissionAmount = course.CommissionAmount;
            modcontext.Training.Add(training);
            modcontext.SaveChanges();
            return Ok(new { status = "Training details" , details = training});
        }


        [Route("getCourses")]
        [HttpGet]
        public IActionResult GetCourses()
        {
            return Ok(modcontext.Course);
        }
    }
}