import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-trainings',
  templateUrl: './user-trainings.component.html',
  styleUrls: ['./user-trainings.component.css']
})
export class UserTrainingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
