import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-search',
  templateUrl: './mentor-search.component.html',
  styleUrls: ['./mentor-search.component.css']
})
export class MentorSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
