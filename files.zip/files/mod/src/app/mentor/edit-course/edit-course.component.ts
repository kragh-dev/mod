import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edit-course',
  templateUrl: './edit-course.component.html',
  styleUrls: ['./edit-course.component.css']
})
export class EditCourseComponent implements OnInit {

  courseId: number

  constructor(private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.courseId = this.activatedRoute.snapshot.params['id'] as number
  }

}
