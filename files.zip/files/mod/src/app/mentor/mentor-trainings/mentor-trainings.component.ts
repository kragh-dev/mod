import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-trainings',
  templateUrl: './mentor-trainings.component.html',
  styleUrls: ['./mentor-trainings.component.css']
})
export class MentorTrainingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
