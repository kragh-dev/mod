import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MentorServiceService {

  skills
  baseUrl = 'http://localhost:5000/api/'
  constructor(private http: HttpClient) { }

  getSkills()
  {
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.get(this.baseUrl+"mentor/getSkills",options)
  }
  getMyCourses(id:any)
  {
    let body = id
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.get(this.baseUrl+"mentor/getCoursesById/"+body,options)
  }
}
